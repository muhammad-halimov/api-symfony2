import{g as o}from"./@babel-35264745.js";var p=u;function u(a,t){var r,e=null;try{r=JSON.parse(a,t)}catch(s){e=s}return[e,r]}const n=o(p);export{n as s};
