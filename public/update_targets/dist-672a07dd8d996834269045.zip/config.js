window.API = 'https://yanishpole-api.itlabs.top'
window.CEF = false
window.TIMEOUT = 90
window.IS_DEV = true
window.wallInterval = 60 // Интервал для стены
